Heleospace brand kit
====================

logo-black / logo-white   The full logo. Use this one by default.
mark-black / mark-white   The mark alone, for small and square spaces.

SVG is best for almost everything. PNG files have transparent backgrounds.

Use the files as they are. Do not recolour, stretch, redraw or add effects.
Full guidelines and terms of use: https://heleo.space/brand/
Questions: hello@heleo.space
